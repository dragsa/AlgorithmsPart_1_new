
import java.util.Arrays;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dragsa
 */
public class Fast {

    public static void main(String[] args) {

        StdDraw.setXscale(0, 20);
        StdDraw.setYscale(0, 20);
        StdDraw.show(0);

        String filename = args[0];
        In in = new In(filename);
        int N = in.readInt();
        Point[] point = new Point[N];
        StdDraw.setPenRadius(0.01);
        for (int i = 0; i < point.length; i++) {
            point[i] = new Point(in.readInt(), in.readInt());
                point[i].draw();
        }
        
        for (int i = 0; i < point.length; i++) {
            Arrays.sort(point, point[i].SLOPE_ORDER);
        }
        StdDraw.show(0);
    }
}
